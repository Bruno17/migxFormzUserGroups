<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxformzusergroups-0.5.1-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e2f80fb71367d2ddaf5b220aa803a177',
      'native_key' => 'migxformzusergroups',
      'filename' => 'modNamespace/35361c663607649c7d9a085d2ad29439.vehicle',
      'namespace' => 'migxformzusergroups',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'eca5b680a2eeb1b3e33536a3fcfdf7a6',
      'native_key' => 1,
      'filename' => 'modCategory/ec175e9f10a15711cb9cc7eec880b202.vehicle',
      'namespace' => 'migxformzusergroups',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '300f521f61832488de04d7a5381d7717',
      'native_key' => 'Formz Usergroups',
      'filename' => 'modMenu/709b79598d1509a1390da251a21e49a4.vehicle',
      'namespace' => 'migxformzusergroups',
    ),
  ),
);