<?php
require_once (dirname(dirname(__FILE__)) . '/fmzforms.class.php');
class fmzForms_mysql extends fmzForms {}