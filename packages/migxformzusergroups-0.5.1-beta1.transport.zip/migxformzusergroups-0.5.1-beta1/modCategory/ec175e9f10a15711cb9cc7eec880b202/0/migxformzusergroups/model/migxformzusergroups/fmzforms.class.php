<?php
class fmzForms extends xPDOSimpleObject {}