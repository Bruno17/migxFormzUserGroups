<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxformzusergroups-0.5.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6e2b884b207e9aba8c89fbb8d6f80dc3',
      'native_key' => 'migxformzusergroups',
      'filename' => 'modNamespace/5b7adc7bbfa64963bb06a50db4be5dbd.vehicle',
      'namespace' => 'migxformzusergroups',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '01f807ff2526638711b7f62a7cffbfc9',
      'native_key' => 1,
      'filename' => 'modCategory/5607521f7d8a1bcfb92b8b84fd21ac59.vehicle',
      'namespace' => 'migxformzusergroups',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '724d6c537e965a3ece233de86ff5d1ba',
      'native_key' => 'Formz Usergroups',
      'filename' => 'modMenu/1bc004e8491f27fdb2a0273a72815b60.vehicle',
      'namespace' => 'migxformzusergroups',
    ),
  ),
);