<?php
require_once (dirname(dirname(__FILE__)) . '/fmzformsusergroup.class.php');
class fmzFormsUsergroup_mysql extends fmzFormsUsergroup {}