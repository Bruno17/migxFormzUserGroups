<?php
class fmzFormsUsergroup extends xPDOSimpleObject {}